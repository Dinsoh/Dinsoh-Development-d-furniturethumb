# Installation and Usage

## 1. Install the resource

Extract the `d-furniturethumb` directory into your FiveM server's `resources` folder. Keep `client.lua`, `server.js`, `png.js`, `config.lua`, `fxmanifest.lua`, and `models.json` together in the resource root.

## 2. Install dependencies and stream your props

Install the official [`screenshot-basic`](https://github.com/citizenfx/screenshot-basic) resource if it is not already present. Ensure all furniture packs containing the target models are started before capturing.

## 3. Configure the model list

Open `models.json`. It must be a JSON array of model-name strings, for example:

```json
["prop_chair_01a", "prop_table_01"]
```

Replace the sample names with models available on your server. The bundled list is specific to the original catalog and is not universal. Restart `d-furniturethumb` after editing the list.

## 4. Configure server.cfg

Place the resource startup lines after your furniture packs:

```cfg
ensure screenshot-basic
ensure d-furniturethumb
```

Grant the command to a trusted ACE group:

```cfg
add_ace group.admin command.furnthumb allow
```

Your player must actually belong to that ACE group. A QB admin permission alone does not automatically establish ACE membership. Alternatively, grant access to one license identifier:

```cfg
add_ace identifier.license:YOUR_LICENSE_HERE command.furnthumb allow
```

Grant filesystem access for screenshot output. Use the resource name matching your screenshot provider:

```cfg
# If using the original screenshot-basic resource:
add_filesystem_permission screenshot-basic write d-furniturethumb

# If using a screencapture-based installation instead, use this in place of the above:
# add_filesystem_permission screencapture write d-furniturethumb
```

These are alternative permission setups, not two permissions everyone must add. Confirm your server artifact supports the relevant filesystem permission command.

## 5. Test the capture

1. Join your **test server** with the ACE-authorized account.
2. Stand on foot in a safe location, close menus, and hide any custom HUD.
3. Run `/furnthumb test`.
4. Wait for capture to finish; avoid switching focus or opening overlays.
5. Inspect `d-furniturethumb/output/` **on the server**, including `report.csv` and any `review/` images.
6. If results are acceptable, run `/furnthumb all`.

Use `/furnthumb single MODEL_NAME` to redo one image, `/furnthumb redo` to regenerate the entire list with backups, or `/furnthumb stop` (or Escape) to cancel.

## 6. Import the results

Copy the approved PNGs into your housing system's or UI's required image folder and follow that resource's refresh/restart process. **This tool does not automatically import images** into other resources.

Stop and remove `d-furniturethumb` from your server when the job is done, and remove any ACE permission you created solely for this tool.

## Troubleshooting

| Symptom | What to check |
| --- | --- |
| Command denied | Check ACE group membership or your `identifier.license` rule |
| `screenshot-basic` not started | Ensure dependency is installed and started first |
| PNG not written | Check the `add_filesystem_permission` rule, resource name, and server console |
| Missing models | Verify spelling and that the furniture pack is started/streamed |
| Furniture cropped or off-center | Inspect `output/review/`; try `single` or `redo`, and adjust framing settings if necessary |
| Texture not fully loaded | Increase `SettleTime` in `config.lua` |
| HUD or overlays in images | Hide custom UI before capture; generic custom NUI overlays cannot always be hidden automatically |
| Screenshot times out | Check client F8, server console, screenshot resource health, and `CaptureTimeout` |
| Studio movement conflicts | Review anti-cheat or movement restrictions; change `Stage` in `config.lua` if necessary |

## Notes

The studio uses client-local props and does not change global weather or server time. Image output uses an opaque neutral background rather than transparency. Captures of unusual materials, animations, or extreme shapes may need manual review.
