ThumbConfig = {
    Stage = vector3(0.0, 0.0, 1800.0),
    LoadTimeout = 10000,
    SettleTime = 1800,
    CaptureTimeout = 30000,
    CameraFov = 35.0,
    BackgroundA = {210, 215, 220},
    BackgroundB = {50, 90, 130},
}
