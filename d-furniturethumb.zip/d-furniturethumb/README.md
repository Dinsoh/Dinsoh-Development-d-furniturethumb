# d-furniturethumb

**FiveM furniture and prop thumbnail capture utility** by **Dinsoh Development**.

Capture consistent 512 × 512 PNG thumbnails of streamed furniture and props for use in housing catalogs and other FiveM interfaces. Designed as a **temporary developer/admin tool on a test server**, not a player-facing production resource.

## Features

- Batch capture from `models.json`, with resume/skip-existing behavior
- Single-model recapture and full redo with backups
- Automatic silhouette centering and camera back-off for clipped objects
- Neutral studio backdrop and 512 × 512 PNG export
- CSV capture report, review folder for unreliable captures, and console diagnostics
- ACE-restricted commands; only one active capture session

> **Rendering limitations:** Unusual, transparent, animated, or very large props may still require review. The tool captures actual rendered screenshots, not transparent-background cutouts.

## Requirements

- FiveM server with your furniture/prop resources started
- [`screenshot-basic`](https://github.com/citizenfx/screenshot-basic)
- ACE permission to use `command.furnthumb`
- Screenshot resource filesystem write permission

## Quick start

1. Copy `d-furniturethumb` into your server's resources folder.
2. Edit `models.json` to contain **your own** target model names. The included list was created for a particular furniture catalog and may not exist on your server.
3. Follow **[INSTALLATION.md](INSTALLATION.md)** for dependency, permission, and `server.cfg` setup.
4. In-game, run `/furnthumb test` and inspect the generated PNGs before starting a full batch.

## Commands

| Command | Description |
| --- | --- |
| `/furnthumb test` | Capture up to five successful thumbnails, skipping missing models as needed |
| `/furnthumb all` | Process remaining models and skip existing PNGs |
| `/furnthumb redo` | Reprocess every model; back up old PNGs before replacing them |
| `/furnthumb single MODEL_NAME` | Recapture one model listed in `models.json` |
| `/furnthumb stop` | Cancel the active session and restore the player |

Press **Escape** during capture to cancel.

## Output

Thumbnails are saved **on the server** to `d-furniturethumb/output/MODEL_NAME.png`. `output/report.csv` records attempts; uncertain images go to `output/review/`; redo backups go under `output/backups/`.

Copy reviewed PNGs into your own housing or UI resource's expected image directory. The tool **does not modify your housing scripts, database, or furniture catalog**.

## Configuration

`config.lua` exposes studio location, model loading and screenshot timeouts, settling time, camera FOV, and backdrop colors. `models.json` is the list of capture targets; restart the resource after editing it.

## Usage notes

- Use a **test server** and ensure your custom furniture assets are legally accessible and started.
- Stand on foot, close menus, hide custom HUD overlays, and keep FiveM focused.
- Your character is temporarily moved into a local capture studio and returned when the session ends. Anti-cheat or movement restrictions may interfere.
- No Blender, Sollumz, npm installation, or Discord webhook is required.
- Captured props may be affected by custom graphics packs or post-processing.

## Troubleshooting

See **[INSTALLATION.md](INSTALLATION.md#troubleshooting)** for common permission, dependency, missing model, and capture problems.

## Project status

**v1.1.0** — Initial GitHub packaging of the supplied working script. The original resource's test notes describe mocked-runtime and image-processing validation; **this packaging has not been retested inside FiveM**. Verify with `/furnthumb test` before a full batch.

## Credits

Developed by **Dinsoh Development**. `screenshot-basic` is a separate third-party dependency maintained by its respective authors.

## License

No license is granted by default. See [LICENSE](LICENSE). The maintainer can replace this with an open-source license when ready to authorize redistribution and modifications.
