'use strict';
// Small PNG cropper for screenshot-basic's RGB/RGBA, 8-bit, non-interlaced PNGs.
// No npm installation needed. Reject unsupported encodings rather than guessing.
const zlib = require('zlib');
const signature = Buffer.from([137,80,78,71,13,10,26,10]);
const crcTable = Array.from({length:256}, (_, n) => {
    for (let i=0;i<8;i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
    return n >>> 0;
});
function crc(buffer) {
    let n = 0xffffffff;
    for (const b of buffer) n = crcTable[(n ^ b) & 255] ^ (n >>> 8);
    return (n ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
    const name = Buffer.from(type), head = Buffer.alloc(4), tail = Buffer.alloc(4);
    head.writeUInt32BE(data.length); tail.writeUInt32BE(crc(Buffer.concat([name,data])));
    return Buffer.concat([head,name,data,tail]);
}
function paeth(a,b,c) {
    const p=a+b-c, x=Math.abs(p-a), y=Math.abs(p-b), z=Math.abs(p-c);
    return x<=y && x<=z ? a : y<=z ? b : c;
}
function decode(buffer) {
    if (!buffer.subarray(0,8).equals(signature)) throw Error('Not a PNG');
    let header, offset=8; const parts=[];
    while (offset+12<=buffer.length) {
        const size=buffer.readUInt32BE(offset), end=offset+12+size;
        if (end>buffer.length) throw Error('Truncated PNG');
        const type=buffer.toString('ascii',offset+4,offset+8);
        const data=buffer.subarray(offset+8,offset+8+size);
        if (buffer.readUInt32BE(offset+8+size)!==crc(buffer.subarray(offset+4,offset+8+size))) throw Error('PNG checksum failed');
        if (type==='IHDR') header=data;
        if (type==='IDAT') parts.push(data);
        offset=end;
        if (type==='IEND') break;
    }
    if (!header || header.length!==13 || header[8]!==8 || ![2,6].includes(header[9]) || header[10] || header[11] || header[12]) throw Error('Unsupported PNG encoding');
    const width=header.readUInt32BE(0), height=header.readUInt32BE(4), channels=header[9]===6 ? 4 : 3;
    if (!width || !height || width*height>40000000) throw Error('Invalid screenshot dimensions');
    const stride=width*channels, raw=zlib.inflateSync(Buffer.concat(parts),{maxOutputLength:(stride+1)*height});
    if (raw.length!==(stride+1)*height) throw Error('Invalid PNG data length');
    const pixels=Buffer.alloc(stride*height);
    for (let y=0;y<height;y++) {
        const filter=raw[y*(stride+1)];
        if (filter>4) throw Error('Unsupported PNG filter');
        for (let x=0;x<stride;x++) {
            const i=y*stride+x, a=x>=channels ? pixels[i-channels] : 0;
            const b=y ? pixels[i-stride] : 0, c=y && x>=channels ? pixels[i-stride-channels] : 0;
            let predictor=0;
            if (filter===1) predictor=a;
            else if (filter===2) predictor=b;
            else if (filter===3) predictor=Math.floor((a+b)/2);
            else if (filter===4) predictor=paeth(a,b,c);
            pixels[i]=(raw[y*(stride+1)+1+x]+predictor)&255;
        }
    }
    return {width,height,channels,pixels};
}
function encode(width,height,pixels) {
    const header=Buffer.alloc(13); header.writeUInt32BE(width); header.writeUInt32BE(height,4);
    header[8]=8; header[9]=6;
    const raw=Buffer.alloc((width*4+1)*height);
    for (let y=0;y<height;y++) pixels.copy(raw,y*(width*4+1)+1,y*width*4,(y+1)*width*4);
    return Buffer.concat([signature,chunk('IHDR',header),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]);
}
function cropThumbnail(image,box,size=512) {
    const {width,height,channels,pixels}=image;
    const side=box.side, left=box.left, top=box.top;
    const out=Buffer.alloc(size*size*4);
    for (let y=0;y<size;y++) for (let x=0;x<size;x++) {
        const sampleX=left+(x+0.5)*side/size-0.5;
        const sampleY=top+(y+0.5)*side/size-0.5;
        const target=(y*size+x)*4;
        if (sampleX<0 || sampleY<0 || sampleX>width-1 || sampleY>height-1) {
            for (let c=0;c<3;c++) out[target+c]=pixels[c];
            out[target+3]=255;
            continue;
        }
        const sx=sampleX, sy=sampleY;
        const x0=Math.floor(sx), y0=Math.floor(sy), x1=Math.min(x0+1,width-1), y1=Math.min(y0+1,height-1);
        const fx=sx-x0, fy=sy-y0;
        for (let c=0;c<4;c++) {
            if (c===3 && channels===3) {out[target+c]=255;continue;}
            const a=pixels[(y0*width+x0)*channels+c], b=pixels[(y0*width+x1)*channels+c];
            const d=pixels[(y1*width+x0)*channels+c], e=pixels[(y1*width+x1)*channels+c];
            out[target+c]=Math.round((a*(1-fx)+b*fx)*(1-fy)+(d*(1-fx)+e*fx)*fy);
        }
    }
    return encode(size,size,out);
}
function squareThumbnail(buffer,size=512) {
    const image=decode(buffer), side=Math.min(image.width,image.height);
    return cropThumbnail(image,{side,left:(image.width-side)/2,top:(image.height-side)/2},size);
}
// Compare two images with the SAME prop/camera but different studio colors.
// Background changes; visible opaque furniture stays mostly the same. This
// avoids assuming the prop has a different color from a single chroma backdrop.
function fitPair(first,second,size=512) {
    const a=decode(first), b=decode(second);
    if(a.width!==b.width || a.height!==b.height) throw Error('Screen resolution changed during capture');
    const {width,height}=a, count=width*height;
    const difference=i=>{
        const x=i*a.channels,y=i*b.channels;
        return Math.abs(a.pixels[x]-b.pixels[y])+Math.abs(a.pixels[x+1]-b.pixels[y+1])+Math.abs(a.pixels[x+2]-b.pixels[y+2]);
    };
    const samples=[];
    // Robustly estimate the backdrop's actual change after game postprocessing.
    for(let y=1;y<height;y+=Math.max(1,Math.floor(height/40))) {
        for(let x=1;x<width;x+=Math.max(1,Math.floor(width/60))) samples.push(difference(y*width+x));
    }
    samples.sort((x,y)=>x-y);
    const backdropDelta=samples[Math.floor(samples.length*0.8)];
    if(backdropDelta<45) return {action:'unreliable',detail:'Studio color change was not visible, or the prop fills the screen.'};
    const threshold=Math.max(9,backdropDelta*0.25);
    const mask=new Uint8Array(count);
    for(let i=0;i<count;i++) if(difference(i)<threshold) mask[i]=1;
    const queue=new Int32Array(count), minimum=Math.max(12,Math.floor(count*0.000015));
    let left=width,right=-1,top=height,bottom=-1,total=0;
    // Keep substantial connected regions, including separated pieces of a prop;
    // discard isolated compression/postprocessing specks.
    for(let start=0;start<count;start++) {
        if(mask[start]!==1) continue;
        let head=0,tail=1;queue[0]=start;mask[start]=0;
        let loX=width,hiX=-1,loY=height,hiY=-1;
        while(head<tail) {
            const i=queue[head++],x=i%width,y=Math.floor(i/width);
            loX=Math.min(loX,x);hiX=Math.max(hiX,x);loY=Math.min(loY,y);hiY=Math.max(hiY,y);
            if(x>0 && mask[i-1]) {mask[i-1]=0;queue[tail++]=i-1;}
            if(x+1<width && mask[i+1]) {mask[i+1]=0;queue[tail++]=i+1;}
            if(y>0 && mask[i-width]) {mask[i-width]=0;queue[tail++]=i-width;}
            if(y+1<height && mask[i+width]) {mask[i+width]=0;queue[tail++]=i+width;}
        }
        if(tail<minimum) continue;
        left=Math.min(left,loX);right=Math.max(right,hiX);top=Math.min(top,loY);bottom=Math.max(bottom,hiY);total+=tail;
    }
    if(!total) return {action:'unreliable',detail:'No stable furniture silhouette detected; model may be transparent, animated or not rendered.'};
    const edge=Math.max(3,Math.floor(Math.min(width,height)*0.012));
    const bounds={left,right,top,bottom};
    if(left<=edge || top<=edge || right>=width-1-edge || bottom>=height-1-edge) {
        return {action:'zoomout',bounds,detail:'Visible furniture approaches the screenshot edge.'};
    }
    const side=Math.max(right-left+1,bottom-top+1)*1.18;
    const box={side,left:(left+right+1-side)/2,top:(top+bottom+1-side)/2};
    return {action:'save',bounds,png:cropThumbnail(a,box,size),detail:'Visible silhouette centered with 18% square padding.'};
}
module.exports={squareThumbnail,fitPair,decode,encode};
