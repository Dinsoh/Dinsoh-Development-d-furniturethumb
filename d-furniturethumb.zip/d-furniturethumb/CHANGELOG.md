# Changelog

## 1.1.0 — Public repository package

- Added GitHub README, installation and usage guide, and changelog.
- Preserved the supplied 1.1.0 resource code and its existing `models.json`.
- Documented automatic framing, redo backups, review images, and ACE-based access.
- No runtime changes were made as part of this packaging.
