-- Keep the perspective-projected bounding rectangle centered in the square crop.
-- A 3D bounding-box center alone can appear off-center with an angled camera.
local ThumbFraming = {}

function ThumbFraming.solve(size, aspect, fov)
    local function dot(a,b) return a.x*b.x + a.y*b.y + a.z*b.z end
    local function normalize(v)
        local length = math.sqrt(dot(v,v))
        return {x=v.x/length,y=v.y/length,z=v.z/length}
    end
    local direction = normalize({x=0.7,y=-1.0,z=0.55})
    local right = normalize({x=-direction.y,y=direction.x,z=0.0})
    local up = {
        x=direction.y*right.z-direction.z*right.y,
        y=direction.z*right.x-direction.x*right.z,
        z=direction.x*right.y-direction.y*right.x,
    }
    local radius = math.sqrt(dot(size,size))/2.0
    local vertical = math.rad(fov/2.0)
    local halfAngle = math.min(vertical,math.atan(math.tan(vertical)*aspect))
    local distance = radius/math.sin(halfAngle)*1.12
    local corners = {}
    for _,x in ipairs({-size.x/2,size.x/2}) do
        for _,y in ipairs({-size.y/2,size.y/2}) do
            for _,z in ipairs({-size.z/2,size.z/2}) do
                local point={x=x,y=y,z=z}
                corners[#corners+1]={u=dot(point,right),v=dot(point,up),depth=distance-dot(point,direction)}
            end
        end
    end
    local offsetU,offsetV=0.0,0.0
    for _=1,16 do
        local minU,maxU,minV,maxV=math.huge,-math.huge,math.huge,-math.huge
        for _,corner in ipairs(corners) do
            local u=(corner.u-offsetU)/corner.depth
            local v=(corner.v-offsetV)/corner.depth
            minU,maxU=math.min(minU,u),math.max(maxU,u)
            minV,maxV=math.min(minV,v),math.max(maxV,v)
        end
        local errorU,errorV=(minU+maxU)/2.0,(minV+maxV)/2.0
        if math.abs(errorU)+math.abs(errorV)<0.0000001 then break end
        offsetU=offsetU+errorU*distance
        offsetV=offsetV+errorV*distance
    end
    local target={
        x=right.x*offsetU+up.x*offsetV,
        y=right.y*offsetU+up.y*offsetV,
        z=right.z*offsetU+up.z*offsetV,
    }
    return {
        target=target,
        camera={x=target.x+direction.x*distance,y=target.y+direction.y*distance,z=target.z+direction.z*distance},
    }
end


local current
ThumbConfig.BackgroundA = ThumbConfig.BackgroundA or {210,215,220}
ThumbConfig.BackgroundB = ThumbConfig.BackgroundB or {50,90,130}

local function log(message)
    print('[furnthumb] ' .. message)
end

local function removeProp(state)
    if state.prop and DoesEntityExist(state.prop) then
        DeleteEntity(state.prop)
    end
    state.prop = nil
    if state.model then SetModelAsNoLongerNeeded(state.model) end
    state.model = nil
end

local function cleanup(state)
    if state.cleaned then return end
    state.cleaned = true
    state.running = false
    removeProp(state)
    if state.camera then
        RenderScriptCams(false, false, 0, true, true)
        DestroyCam(state.camera, false)
        state.camera = nil
    end
    ClearFocus()
    local saved = state.saved
    if saved and DoesEntityExist(saved.ped) then
        SetEntityCoordsNoOffset(saved.ped, saved.coords.x, saved.coords.y, saved.coords.z, false, false, false)
        SetEntityHeading(saved.ped, saved.heading)
        SetEntityVisible(saved.ped, saved.visible, false)
        FreezeEntityPosition(saved.ped, saved.frozen)
        SetEntityCollision(saved.ped, saved.collision, false)
        if PlayerPedId() == saved.ped then SetPlayerInvincible(PlayerId(), saved.invincible) end
    end
    if current == state then current = nil end
end

local function live(state)
    return current == state and state.running
end

local function waitFor(state, duration)
    local deadline = GetGameTimer() + duration
    while live(state) and GetGameTimer() < deadline do Wait(0) end
    return live(state)
end

local function triangle(a, b, c, color)
    DrawPoly(a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,color[1],color[2],color[3],255)
    DrawPoly(c.x,c.y,c.z,b.x,b.y,b.z,a.x,a.y,a.z,color[1],color[2],color[3],255)
end

local function quad(a,b,c,d,color)
    triangle(a,b,c,color)
    triangle(a,c,d,color)
end

local function backdrop(state)
    local s = ThumbConfig.Stage
    local w = state.room or 30.0
    local bottom = state.floor or (s.z - 5.0)
    local top = s.z + w
    local color = state.phase == 'b' and ThumbConfig.BackgroundB or ThumbConfig.BackgroundA
    local p = {
        vector3(s.x-w,s.y-w,bottom), vector3(s.x+w,s.y-w,bottom),
        vector3(s.x+w,s.y+w,bottom), vector3(s.x-w,s.y+w,bottom),
        vector3(s.x-w,s.y-w,top), vector3(s.x+w,s.y-w,top),
        vector3(s.x+w,s.y+w,top), vector3(s.x-w,s.y+w,top),
    }
    quad(p[1],p[2],p[3],p[4],color)
    quad(p[5],p[6],p[7],p[8],color)
    quad(p[1],p[2],p[6],p[5],color)
    quad(p[2],p[3],p[7],p[6],color)
    quad(p[3],p[4],p[8],p[7],color)
    quad(p[4],p[1],p[5],p[8],color)
    local radius = state.radius or 2.0
    DrawLightWithRange(s.x+radius*2,s.y-radius*2,s.z+radius*2,255,255,255,radius*8,3.0)
    DrawLightWithRange(s.x-radius*2,s.y-radius,s.z+radius,255,255,255,radius*8,2.0)
end

local function prepare(state, name)
    local hash = joaat(name)
    state.model = hash
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        return false, 'Model unavailable; check that its furniture pack is started.'
    end
    RequestModel(hash)
    local deadline = GetGameTimer() + ThumbConfig.LoadTimeout
    while live(state) and not HasModelLoaded(hash) and GetGameTimer() < deadline do
        RequestModel(hash)
        Wait(50)
    end
    if not live(state) then return false, 'Cancelled' end
    if not HasModelLoaded(hash) then return false, 'Model load timed out.' end
    local low, high = GetModelDimensions(hash)
    local size = high - low
    local radius = #size / 2.0
    if radius < 0.005 or radius > 100.0 then return false, 'Invalid or excessively large model bounds.' end
    state.radius = math.max(radius, 0.1)
    state.room = math.max(radius * 8.0, 20.0)
    state.floor = ThumbConfig.Stage.z - size.z / 2.0 - 0.025
    local origin = ThumbConfig.Stage - (low + high) / 2.0
    state.prop = CreateObjectNoOffset(hash, origin.x, origin.y, origin.z, false, false, false)
    if not state.prop or state.prop == 0 or not DoesEntityExist(state.prop) then
        state.prop = nil
        return false, 'Could not create object.'
    end
    SetEntityAsMissionEntity(state.prop, true, true)
    FreezeEntityPosition(state.prop, true)
    SetEntityCollision(state.prop, false, false)
    SetEntityLodDist(state.prop, 1000)
    SetEntityHeading(state.prop, 0.0)
    local stage = ThumbConfig.Stage
    local width, height = GetActiveScreenResolution()
    local aspect = width / math.max(height, 1)
    local framing = ThumbFraming.solve(size, aspect, ThumbConfig.CameraFov)
    local cameraPos = stage + vector3(framing.camera.x,framing.camera.y,framing.camera.z)
    local target = stage + vector3(framing.target.x,framing.target.y,framing.target.z)
    state.cameraPos, state.target = cameraPos, target
    SetCamCoord(state.camera, cameraPos.x, cameraPos.y, cameraPos.z)
    PointCamAtCoord(state.camera, target.x, target.y, target.z)
    SetCamFov(state.camera, ThumbConfig.CameraFov)
    SetCamNearClip(state.camera, 0.001)
    SetCamFarClip(state.camera, math.max(state.room * 10.0, 300.0))
    SetFocusPosAndVel(stage.x,stage.y,stage.z,0.0,0.0,0.0)
    return true
end

RegisterNetEvent('furnthumb:ack', function(id, model, ok, detail)
    if current and current.id == id and current.waiting == model then
        current.reply = {ok = ok, detail = detail}
    end
end)

RegisterNetEvent('furnthumb:step', function(id, model, action)
    if current and current.id == id and current.waiting == model then
        current.step = action
    end
end)

RegisterNetEvent('furnthumb:stop', function(id)
    if current and current.id == id then cleanup(current) end
end)

RegisterNetEvent('furnthumb:begin', function(id, models)
    if current then return end
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) then
        log('Exit your vehicle and be alive before starting.')
        TriggerServerEvent('furnthumb:cancel', id, 'Start alive and on foot.')
        return
    end
    local state = {id=id, running=true, phase='a', saved={
        ped=ped, coords=GetEntityCoords(ped), heading=GetEntityHeading(ped),
        visible=IsEntityVisible(ped), collision=not GetEntityCollisionDisabled(ped),
        frozen=IsEntityPositionFrozen(ped), invincible=GetPlayerInvincible(PlayerId()),
    }}
    current = state
    CreateThread(function()
        local ok, errorMessage = xpcall(function()
            FreezeEntityPosition(ped, true)
            SetPlayerInvincible(PlayerId(), true)
            SetEntityVisible(ped, false, false)
            SetEntityCollision(ped, false, false)
            local stage = ThumbConfig.Stage
            SetEntityCoordsNoOffset(ped,stage.x,stage.y,stage.z-10.0,false,false,false)
            state.camera = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
            SetCamCoord(state.camera,stage.x,stage.y-8.0,stage.z+3.0)
            PointCamAtCoord(state.camera,stage.x,stage.y,stage.z)
            RenderScriptCams(true, false, 0, true, true)
            -- Let the command's chat message fade before the first screenshot.
            if not waitFor(state, 8000) then return end
            for index, model in ipairs(models) do
                if not live(state) then break end
                removeProp(state)
                state.waiting, state.reply, state.step, state.phase = model, nil, nil, 'a'
                local loaded, reason = prepare(state, model)
                if not live(state) then break end
                if loaded then
                    if not waitFor(state, ThumbConfig.SettleTime) then break end
                    TriggerServerEvent('furnthumb:capture', id, model, state.phase)
                else
                    TriggerServerEvent('furnthumb:skip', id, model, reason)
                end
                local deadline = GetGameTimer() + ThumbConfig.CaptureTimeout
                while live(state) and not state.reply and GetGameTimer() < deadline do
                    if state.step then
                        local action = state.step
                        state.step = nil
                        if action == 'alternate' then
                            state.phase = 'b'
                        elseif action == 'zoomout' then
                            state.phase = 'a'
                            local delta = (state.cameraPos - state.target) * 1.6
                            state.cameraPos = state.target + delta
                            state.room = math.max(state.room, #delta * 2.0)
                            SetCamFarClip(state.camera, state.room * 10.0)
                            SetCamCoord(state.camera,state.cameraPos.x,state.cameraPos.y,state.cameraPos.z)
                            PointCamAtCoord(state.camera,state.target.x,state.target.y,state.target.z)
                            log(model .. ': automatically backing the camera out.')
                        else
                            error('Unexpected auto-fit instruction: ' .. tostring(action))
                        end
                        if not waitFor(state, ThumbConfig.SettleTime) then break end
                        TriggerServerEvent('furnthumb:capture', id, model, state.phase)
                        deadline = GetGameTimer() + ThumbConfig.CaptureTimeout
                    end
                    Wait(50)
                end
                if not live(state) then break end
                if not state.reply then error('Screenshot/acknowledgement timed out. Check screenshot-basic and server console.') end
                log(('%d/%d %s: %s'):format(index,#models,model,state.reply.ok and 'saved' or state.reply.detail))
                if not waitFor(state, 100) then break end
            end
        end, debug.traceback)
        if not ok then log(errorMessage) end
        if live(state) then TriggerServerEvent('furnthumb:cancel', id, ok and 'Client finished.' or errorMessage) end
        cleanup(state)
    end)
    CreateThread(function()
        while live(state) do
            HideHudAndRadarThisFrame()
            DisableAllControlActions(0)
            EnableControlAction(0,245,true) -- Allow opening chat to issue /furnthumb stop.
            if IsDisabledControlJustPressed(0,200) or PlayerPedId() ~= ped or IsEntityDead(ped) then
                TriggerServerEvent('furnthumb:cancel', id, 'Escape pressed, player died, or player ped changed.')
                cleanup(state)
                break
            end
            backdrop(state)
            Wait(0)
        end
    end)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() and current then cleanup(current) end
end)
