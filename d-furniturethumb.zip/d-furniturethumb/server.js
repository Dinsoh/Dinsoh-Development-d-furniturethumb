'use strict';
const fs=require('fs'), path=require('path'), crypto=require('crypto');
const resource=GetCurrentResourceName(), root=GetResourcePath(resource);
const {fitPair}=require(path.join(root,'png.js'));
const output=path.join(root,'output'); fs.mkdirSync(output,{recursive:true});
const models=JSON.parse(LoadResourceFile(resource,'models.json'));
if (!Array.isArray(models) || models.some(m=>typeof m!=='string' || !/^[a-zA-Z0-9_]+$/.test(m))) throw Error('Invalid models.json');
const allowed=new Set(models);
let session=null;
function notify(src,message) {
    emitNet('chat:addMessage',src,{color:[110,190,255],args:['Furniture thumbs',message]});
    console.log(`[furnthumb] ${message}`);
}
function report(model,status,detail='') {
    const quote=s=>'"'+String(s).replace(/"/g,'""')+'"';
    const reportPath=path.join(output,'report.csv');
    if (!fs.existsSync(reportPath)) fs.writeFileSync(reportPath,'time,model,status,detail\n');
    fs.appendFileSync(reportPath,[new Date().toISOString(),model,status,detail].map(quote).join(',')+'\n');
}
function end(reason) {
    if (!session) return;
    const old=session; session=null;
    emitNet('furnthumb:stop',old.src,old.id);
    notify(old.src,`${reason} Saved ${old.saved}, skipped ${old.skipped}. Images: ${output}`);
}
RegisterCommand('furnthumb',(src,args)=>{
    if (!src) return console.log('Use /furnthumb in game.');
    const mode=(args[0]||'test').toLowerCase();
    if (mode==='stop') {
        if (session?.src===src) end('Cancelled.');
        return;
    }
    if (session) return notify(src,'A capture session is already running.');
    if (GetResourceState('screenshot-basic')!=='started') return notify(src,'Start screenshot-basic first.');
    if (!['test','all','redo','single'].includes(mode)) return notify(src,'Use /furnthumb test, all, redo, single MODEL, or stop.');
    let list=mode==='redo' ? models : models.filter(m=>!fs.existsSync(path.join(output,m+'.png')));
    if (mode==='single') {
        const model=args[1];
        if (!allowed.has(model)) return notify(src,'Model must be in models.json.');
        list=[model];
    }
    if (!list.length) return notify(src,'All target PNGs already exist. Use single MODEL to recapture one.');
    session={src,id:crypto.randomBytes(16).toString('hex'),list,index:0,saved:0,skipped:0,
        busy:false,last:Date.now(),test:mode==='test',phase:'a',attempt:0,first:null};
    // Test tries targets until five successful screenshots, rather than five absent models.
    emitNet('furnthumb:begin',src,session.id,list,session.test);
    notify(src,`Started ${mode}. Keep the game focused, close menus and hide your custom HUD. /furnthumb stop cancels.`);
},true);
function valid(src,id,model) {
    return session && session.src===src && session.id===id && !session.busy &&
        session.list[session.index]===model && IsPlayerAceAllowed(String(src),'command.furnthumb');
}
function advance(current,model,ok,detail) {
    if (session!==current) return;
    current.busy=false; current.last=Date.now(); current.index++;
    current.phase='a';current.attempt=0;current.first=null;
    if (ok) current.saved++; else current.skipped++;
    report(model,ok?'saved':'skipped',detail);
    emitNet('furnthumb:ack',current.src,current.id,model,ok,detail);
    if (current.index>=current.list.length || current.test && current.saved>=5) end('Finished.');
}
onNet('furnthumb:skip',(id,model,reason)=>{
    const src=Number(global.source);
    if (!valid(src,id,model)) return;
    const current=session;
    advance(current,model,false,String(reason||'Model failed to load').slice(0,200));
});
onNet('furnthumb:capture',(id,model,phase)=>{
    const src=Number(global.source);
    if (!valid(src,id,model)) return;
    if(phase!==session.phase) return;
    const current=session; current.busy=true; current.last=Date.now();
    // Unique names prevent a late callback from replacing a newer session's image.
    const raw=path.join(output,`.capture-${id}-${current.index}-${current.attempt}-${phase}.png`);
    try {
        exports['screenshot-basic'].requestClientScreenshot(src,{fileName:raw,encoding:'png'},(error)=>{
            if (session!==current) {try {fs.unlinkSync(raw);} catch {} return;}
            if (error) return advance(current,model,false,`Screenshot failed: ${error}`);
            try {
                const image=fs.readFileSync(raw);
                fs.unlinkSync(raw);
                if(phase==='a') {
                    current.first=image;current.phase='b';current.busy=false;current.last=Date.now();
                    emitNet('furnthumb:step',src,id,model,'alternate');
                    return;
                }
                const result=fitPair(current.first,image);
                if(result.action!=='save') {
                    if(current.attempt<5) {
                        current.attempt++;current.phase='a';current.busy=false;current.last=Date.now();current.first=null;
                        emitNet('furnthumb:step',src,id,model,'zoomout');
                        return;
                    }
                    const review=path.join(output,'review');fs.mkdirSync(review,{recursive:true});
                    fs.writeFileSync(path.join(review,model+'.png'),current.first);
                    advance(current,model,false,`Auto-fit needs review after 5 zoom-outs: ${result.detail}`);
                    return;
                }
                const destination=path.join(output,model+'.png');
                if(fs.existsSync(destination)) {
                    const backup=path.join(output,'backups',id);fs.mkdirSync(backup,{recursive:true});
                    fs.copyFileSync(destination,path.join(backup,model+'.png'));
                }
                fs.writeFileSync(destination,result.png);
                advance(current,model,true,`512x512 auto-fit; zoom-outs ${current.attempt}; ${result.detail}`);
            } catch (error) {
                console.error('[furnthumb]',error);
                advance(current,model,false,`Image processing failed: ${error.message}`);
            }
        });
    } catch (error) {advance(current,model,false,error.message);}
});
onNet('furnthumb:cancel',(id,reason)=>{
    if (session?.src===Number(global.source) && session.id===id) end('Cancelled: '+String(reason||'client stopped').slice(0,240));
});
on('playerDropped',()=>{if (session?.src===Number(global.source)) end('Player disconnected.');});
setInterval(()=>{if (session && Date.now()-session.last>45000) end('Timed out.');},5000);
on('onResourceStop',(name)=>{if(name===resource) end('Resource stopped.');});
