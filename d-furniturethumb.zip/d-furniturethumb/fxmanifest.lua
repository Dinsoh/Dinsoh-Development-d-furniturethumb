fx_version 'cerulean'
game 'gta5'

author 'Dinsoh Development'
description 'Temporary local furniture thumbnail capture tool'
version '1.1.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.js'
dependency 'screenshot-basic'
