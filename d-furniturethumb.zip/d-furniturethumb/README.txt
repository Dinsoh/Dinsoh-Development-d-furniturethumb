DINSoH DEVELOPMENT — TEMPORARY FURNITURE THUMBNAILS

SETUP (USE YOUR TEST SERVER)
1. Put d-furniturethumb in your server resources folder.
2. Keep your furniture packs started; their YDR/YTD/YTYPs must load normally.
3. If you do not already have screenshot-basic, install the official resource:
   https://github.com/citizenfx/screenshot-basic
   Download/extract it with the folder name screenshot-basic. Its standard
   FiveM build dependencies must be available; verify it starts without errors.
4. Add these lines to server.cfg after the furniture packs:

   add_ace group.admin command.furnthumb allow
   add_filesystem_permission screencapture write d-furniturethumb
   ensure screenshot-basic
   ensure d-furniturethumb

Your identifier must belong to group.admin in your existing ACE setup. A QB
admin role alone is not necessarily an ACE principal. To grant this command
to only yourself instead, use:
   add_ace identifier.license:YOUR_LICENSE_HERE command.furnthumb allow
Use your actual license identifier from the server console/player list.
The filesystem permission above is for screencapture installations providing
the screenshot-basic API. If using original screenshot-basic instead, use:
   add_filesystem_permission screenshot-basic write d-furniturethumb

COMMANDS (IN GAME)
/furnthumb test
  Captures up to 5 successful images, trying past unavailable models.
  If all models are missing this may try the whole target list and save none.
/furnthumb all
  Processes remaining targets; existing PNGs in output are skipped.
/furnthumb redo
  Reprocesses ALL targets with auto-fit, including previously captured items.
  Old PNGs are backed up under output/backups/SESSION_ID before replacement.
/furnthumb single atr_calm_living_art
  Recaptures that model, replacing its existing PNG. Must be in models.json.
/furnthumb stop
  Cancels and restores your character. Escape also cancels.

The supplied models.json includes the 512 missing thumbnails from your
origen_housing3(2).zip. Edit that file to change targets; restart this resource
after editing. Nothing is written to your housing resource or database.

BEFORE CAPTURING
- Stand on foot in a safe place, close all menus, and hide your custom HUD.
- Keep FiveM focused. Disable cinematic bars, filters or overlays that would
  appear in screenshots. A custom NUI HUD/chat cannot be hidden generically
  by this tool; GTA HUD/radar are hidden per frame during the session.
- Start with test and check image quality before all.
- Your player temporarily moves to a local studio at altitude, becomes
  invisible, frozen and invincible, then returns to the saved position.
  Any anticheat/admin movement policy must permit this on your test server.
- It does not change weather, time, routing buckets or global server state.

RESULTS
PNG files save ON THE SERVER into:
resources/[your folder]/d-furniturethumb/output/MODEL_NAME.png
Each prop is captured against two alternating studio backdrops. Comparing the
two images locates visible furniture independently of the model's declared
bounds and color. If its silhouette approaches a full-screen edge, the camera
backs out 60% and tries again, up to five times. A complete silhouette is then
centered and cropped to 512x512 with 18% padding. The temporary backdrop changes
are expected; do not adjust the camera during the process.
No Blender, Sollumz, npm install or Discord webhook is required.
They use an opaque neutral gray studio background, not transparent cutouts.
Copy reviewed PNGs into origen_housing/ui/img/furniture/ and restart housing.
Then stop/remove d-furniturethumb. Remove its temporary ACE permission too.

output/report.csv records each attempted model and capture result. Unreliable
auto-fit results go into output/review/ for checking, and are marked skipped
rather than replacing a good existing PNG. Transparent/animated props, custom
HUD overlays, and postprocessing can confuse silhouette detection. The batch
continues after the five retries. Server
console and client F8 have diagnostic messages. Capture failures stop/skip
without claiming a successful image.

TECHNICAL NOTES
- One session at a time; commands and events are ACE restricted.
- Props are client-local, one at a time. Nothing runs per frame when idle.
- A random session ID and ordered model list reject unsolicited capture paths.
- Existing output files allow resuming a cancelled batch.
- Model-load timeout: 10s; screenshot timeout: 30s.
- Camera is framed from actual model bounds for a centered square screenshot.
- Version 1.1.0 centers the visible silhouette and automatically backs out on
  clipping. Framing code is embedded in client.lua; no separate framing.lua
  dependency. Use redo to replace old captures with automatic backups.
- Missing/unstarted models are logged. Escrow assets can be captured if they
  already load on your authorized server/client; this does not decrypt them.
- Some models may need a different viewpoint, material streaming delay, or
  lighting tweaks. Adjust config.lua SettleTime if textures load slowly.
- Stage changes in config.lua are local. Pick a remote location if another
  resource moves your player or imposes altitude limits.
- Large batch capture is a temporary admin workflow, not a production feature.
- Captures are actual screen renders, so graphics packs and weather may affect
  appearance even though the studio provides a backdrop and local lights.

VALIDATION
PNG decoding/cropping was checked against RGB/RGBA screenshots and PNG filters.
Server permission/session behavior was checked with a mocked FiveM runtime.
Auto-fit tests cover off-center props, screen-edge clipping, sparse noise,
detached furniture parts, ambiguous captures, retries, and backup behavior.
Actual FiveM rendering and screenshot-basic integration require in-server
testing. They were not executed here. Run /furnthumb test before the full batch.
